using System;
namespace DbMigrations
{
    [AttributeUsage(AttributeTargets.Class)] public class TableAttribute : Attribute { public string Name { get; } public TableAttribute(string n) => Name = n; }
    [AttributeUsage(AttributeTargets.Property)] public class ColumnAttribute : Attribute { }
    [AttributeUsage(AttributeTargets.Property)] public class PrimaryKeyAttribute : Attribute { }
}