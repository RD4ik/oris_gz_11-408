namespace DbMigrations
{
    public class Migration
    {
        public string Name { get; set; } = "";
        public string UpSql { get; set; } = "";
        public string DownSql { get; set; } = "";
        public string ModelSnapshot { get; set; } = "";
    }

    public class MigrationRecord
    {
        public int Id { get; set; }
        public string MigrationName { get; set; } = "";
        public DateTimeOffset AppliedAt { get; set; }
        public string ModelSnapshot { get; set; } = "";
        public string UpSql { get; set; } = "";
        public string DownSql { get; set; } = "";
    }
}