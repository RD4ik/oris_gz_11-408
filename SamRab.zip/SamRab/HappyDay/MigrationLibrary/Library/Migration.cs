namespace DbMigrations
{
    public class Migration
    {
        public string Name { get; set; } = string.Empty;
        public string UpSql { get; set; } = string.Empty;
        public string DownSql { get; set; } = string.Empty;
        public string ModelSnapshot { get; set; } = string.Empty;
    }

    public class MigrationRecord
    {
        public int Id { get; set; }
        public string MigrationName { get; set; } = string.Empty;
        public DateTimeOffset AppliedAt { get; set; }
        public string ModelSnapshot { get; set; } = string.Empty;
        public string UpSql { get; set; } = string.Empty;
        public string DownSql { get; set; } = string.Empty;
    }
}