using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace DbMigrations
{
    public class DbMigrator
    {
        private readonly string _connectionString;
        private readonly Type[] _modelTypes;

        public DbMigrator(string connectionString, params Type[] modelTypes)
        {
            _connectionString = connectionString;
            _modelTypes = modelTypes;
        }

        public async Task EnsureMigrationsTableExistsAsync()
        {
            using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync();

            string createTableSql = @"
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='_migrations' AND xtype='U')
                CREATE TABLE _migrations (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    migration_name NVARCHAR(MAX),
                    applied_at DATETIMEOFFSET,
                    model_snapshot NVARCHAR(MAX),
                    up_sql NVARCHAR(MAX),
                    down_sql NVARCHAR(MAX)
                )";

            using var command = new SqlCommand(createTableSql, connection);
            await command.ExecuteNonQueryAsync();
        }

        public async Task<Migration> CreateMigrationAsync(string migrationName)
        {
            var upSql = new StringBuilder();
            var downSql = new StringBuilder();

            foreach (var modelType in _modelTypes)
            {
                var tableAttr = modelType.GetCustomAttribute<TableAttribute>();
                if (tableAttr == null) continue;

                var tableName = tableAttr.Name;
                var columns = new List<(string Name, string Type, bool IsPk)>();

                foreach (var prop in modelType.GetProperties())
                {
                    if (prop.GetCustomAttribute<ColumnAttribute>() != null)
                    {
                        string sqlType = prop.PropertyType.Name switch
                        {
                            "Int32" => "INT",
                            "String" => "NVARCHAR(255)", 
                            _ => "NVARCHAR(255)" 
                        };
                        bool isPk = prop.GetCustomAttribute<PrimaryKeyAttribute>() != null;
                        columns.Add((prop.Name, sqlType, isPk));
                    }
                }

                upSql.AppendLine($"CREATE TABLE [{tableName}] (");
                for (int i = 0; i < columns.Count; i++)
                {
                    var col = columns[i];
                    upSql.Append($"    [{col.Name}] {col.Type}");
                    if (col.IsPk) upSql.Append(" PRIMARY KEY");
                    if (i < columns.Count - 1) upSql.Append(",");
                    upSql.AppendLine();
                }
                upSql.AppendLine(");");

                downSql.AppendLine($"DROP TABLE [{tableName}];");
            }

            var snapshot = JsonSerializer.Serialize(_modelTypes.Select(t => t.FullName));

            return new Migration
            {
                Name = migrationName,
                UpSql = upSql.ToString().Trim(),
                DownSql = downSql.ToString().Trim(),
                ModelSnapshot = snapshot
            };
        }
    }
}