using System.Net;
using System.Text;
using System.Text.Json;
using DbMigrations;

namespace ConsoleApplication
{
    public class DbMigrationHttpApi
    {
        private readonly HttpListener _listener;
        private readonly DbMigrator _migrator;
        private readonly List<Migration> _pendingMigrations = new();

        public DbMigrationHttpApi(string urlPrefix, DbMigrator migrator)
        {
            _listener = new HttpListener();
            _listener.Prefixes.Add(urlPrefix);
            _migrator = migrator;
        }

        public async Task StartAsync()
        {
            _listener.Start();
            Console.WriteLine("HTTP API запущен на " + _listener.Prefixes.First());

            while (_listener.IsListening)
            {
                var context = await _listener.GetContextAsync();
                _ = Task.Run(() => HandleRequestAsync(context));
            }
        }

        private async Task HandleRequestAsync(HttpListenerContext context)
        {
            var request = context.Request;
            var response = context.Response;

            string responseString = "";
            int statusCode = 200;

            try
            {
                switch (request.Url.AbsolutePath)
                {
                    case "/migrate/create":
                        var newMigration = await _migrator.CreateMigrationAsync($"AutoMigration_{DateTimeOffset.Now:yyyyMMddHHmmss}");
                        _pendingMigrations.Add(newMigration);
                        responseString = JsonSerializer.Serialize(new
                        {
                            migration = newMigration.Name,
                            status = "created",
                            up_sql = newMigration.UpSql,
                            down_sql = newMigration.DownSql
                        });
                        break;

                    
                }
            }
            catch (Exception ex)
            {
                statusCode = 500;
                responseString = JsonSerializer.Serialize(new { error = ex.Message });
            }

            response.StatusCode = statusCode;
            response.ContentType = "application/json";
            byte[] buffer = Encoding.UTF8.GetBytes(responseString);
            await response.OutputStream.WriteAsync(buffer, 0, buffer.Length);
            response.Close();
        }
    }
}