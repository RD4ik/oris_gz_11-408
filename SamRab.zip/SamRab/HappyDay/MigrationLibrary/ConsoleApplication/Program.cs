using ConsoleApplication.Models;
using DbMigrations;

namespace ConsoleApplication
{
    class Program
    {
        static async Task Main(string[] args)
        {
            var connectionString = "Server=localhost;Database=TestDb;Trusted_Connection=true;";
            var migrator = new DbMigrator(connectionString, typeof(User));

            await migrator.EnsureMigrationsTableExistsAsync();

            var api = new DbMigrationHttpApi("http://localhost:8080/", migrator);
            await api.StartAsync();
        }
    }
}